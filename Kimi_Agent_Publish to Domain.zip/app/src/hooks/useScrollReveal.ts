import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface ScrollRevealOptions {
  y?: number;
  opacity?: number;
  duration?: number;
  delay?: number;
  stagger?: number;
  start?: string;
  end?: string;
  scrub?: boolean | number;
}

export function useScrollReveal<T extends HTMLElement>(
  options: ScrollRevealOptions = {}
) {
  const ref = useRef<T>(null);
  const triggersRef = useRef<ScrollTrigger[]>([]);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const {
      y = 30,
      opacity = 0,
      duration = 0.6,
      delay = 0,
      stagger = 0.08,
      start = 'top 85%',
      end = 'top 50%',
      scrub = false,
    } = options;

    // Check for reduced motion preference
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    if (prefersReducedMotion) {
      // Simple fade for reduced motion
      gsap.set(element, { opacity: 1 });
      return;
    }

    const children = element.children.length > 0 ? element.children : [element];

    const animation = gsap.fromTo(
      children,
      {
        y,
        opacity,
      },
      {
        y: 0,
        opacity: 1,
        duration,
        delay,
        stagger,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: element,
          start,
          end,
          scrub,
          toggleActions: 'play none none reverse',
        },
      }
    );

    if (animation.scrollTrigger) {
      triggersRef.current.push(animation.scrollTrigger);
    }

    return () => {
      triggersRef.current.forEach(st => st.kill());
      triggersRef.current = [];
      animation.kill();
    };
  }, [options.y, options.opacity, options.duration, options.delay, options.stagger, options.start, options.end, options.scrub]);

  return ref;
}

// Hook for individual element reveal
export function useElementReveal<T extends HTMLElement>(
  options: ScrollRevealOptions = {}
) {
  const ref = useRef<T>(null);
  const triggersRef = useRef<ScrollTrigger[]>([]);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const {
      y = 24,
      opacity = 0,
      duration = 0.5,
      delay = 0,
      start = 'top 85%',
    } = options;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    if (prefersReducedMotion) {
      gsap.set(element, { opacity: 1 });
      return;
    }

    const animation = gsap.fromTo(
      element,
      {
        y,
        opacity,
      },
      {
        y: 0,
        opacity: 1,
        duration,
        delay,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: element,
          start,
          toggleActions: 'play none none reverse',
        },
      }
    );

    if (animation.scrollTrigger) {
      triggersRef.current.push(animation.scrollTrigger);
    }

    return () => {
      triggersRef.current.forEach(st => st.kill());
      triggersRef.current = [];
      animation.kill();
    };
  }, [options.y, options.opacity, options.duration, options.delay, options.start]);

  return ref;
}

// Hook for counter animation
export function useCounterAnimation(
  endValue: number,
  suffix: string = '',
  duration: number = 2
) {
  const ref = useRef<HTMLSpanElement>(null);
  const triggersRef = useRef<ScrollTrigger[]>([]);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const obj = { value: 0 };

    const trigger = ScrollTrigger.create({
      trigger: element,
      start: 'top 85%',
      once: true,
      onEnter: () => {
        if (prefersReducedMotion) {
          element.textContent = endValue + suffix;
          return;
        }
        gsap.to(obj, {
          value: endValue,
          duration,
          ease: 'power2.out',
          onUpdate: () => {
            if (element) {
              element.textContent = Math.round(obj.value) + suffix;
            }
          },
        });
      },
    });

    triggersRef.current.push(trigger);

    return () => {
      triggersRef.current.forEach(st => st.kill());
      triggersRef.current = [];
    };
  }, [endValue, suffix, duration]);

  return ref;
}
