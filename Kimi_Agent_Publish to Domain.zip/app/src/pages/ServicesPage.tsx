import { useElementReveal } from '../hooks/useScrollReveal';
import { 
  FileText, 
  MessageSquare, 
  Calendar, 
  BarChart3, 
  MapPin, 
  Headphones, 
  CreditCard, 
  Share2, 
  Mail 
} from 'lucide-react';

const services = [
  {
    icon: FileText,
    title: 'Listing Description Writer',
    description: 'Turn notes into polished listings in seconds.',
    tag: 'Saves Time',
    tagColor: 'forest',
  },
  {
    icon: MessageSquare,
    title: 'Lead Follow-Up Agent',
    description: 'Instant, on-brand replies via SMS/email.',
    tag: 'Makes Money',
    tagColor: 'terracotta',
  },
  {
    icon: Calendar,
    title: 'Showing Scheduler',
    description: 'Qualify + book without the back-and-forth.',
    tag: 'Saves Time',
    tagColor: 'forest',
  },
  {
    icon: BarChart3,
    title: 'Market Analysis Reporter',
    description: 'Weekly comps, charts, and commentary.',
    tag: 'Saves Time',
    tagColor: 'forest',
  },
  {
    icon: MapPin,
    title: 'Neighborhood Intel Agent',
    description: 'Schools, commutes, amenities—on demand.',
    tag: 'Reduces Low-Value',
    tagColor: 'warmgray',
  },
  {
    icon: Headphones,
    title: 'Customer Support Chatbot',
    description: 'Answer FAQs and capture leads 24/7.',
    tag: 'Reduces Low-Value',
    tagColor: 'warmgray',
  },
  {
    icon: CreditCard,
    title: 'Invoice & Billing Agent',
    description: 'Draft, send, and follow up on invoices.',
    tag: 'Makes Money',
    tagColor: 'terracotta',
  },
  {
    icon: Share2,
    title: 'Content & Social Writer',
    description: 'Captions, emails, and reminders—scheduled.',
    tag: 'Saves Time',
    tagColor: 'forest',
  },
  {
    icon: Mail,
    title: 'Inbox Triage Agent',
    description: 'Sort, label, and surface what matters.',
    tag: 'Reduces Low-Value',
    tagColor: 'warmgray',
  },
];

export function ServicesPage() {
  const heroRef = useElementReveal<HTMLDivElement>({ y: 30 });
  const gridRef = useElementReveal<HTMLDivElement>({ y: 40, stagger: 0.06 });
  const noteRef = useElementReveal<HTMLDivElement>({ y: 20 });
  const ctaRef = useElementReveal<HTMLDivElement>({ y: 30 });

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    window.location.hash = href;
  };

  const getTagClasses = (color: string) => {
    switch (color) {
      case 'forest':
        return 'bg-forest/10 text-forest border-forest/20';
      case 'terracotta':
        return 'bg-terracotta/10 text-terracotta border-terracotta/20';
      default:
        return 'bg-warmgray/10 text-warmgray border-warmgray/20';
    }
  };

  return (
    <div className="relative pt-24 lg:pt-32">
      {/* Hero Section */}
      <section className="py-16 lg:py-20 bg-cream-50 dark:bg-ink">
        <div className="section-container">
          <div ref={heroRef} className="content-container text-center">
            <span className="eyebrow block mb-4">What We Build</span>
            <h1 className="font-serif text-ink dark:text-cream-50 mb-6">
              AI that works while you{' '}
              <span className="accent-italic">focus on growth.</span>
            </h1>
            <p className="text-lg text-warmgray max-w-2xl mx-auto">
              Pick from proven agents—or ask for a custom build. Each agent integrates with your existing tools and is live within 72 hours.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16 lg:py-20 bg-cream-100 dark:bg-ink/40">
        <div className="section-container">
          <div className="content-container">
            <div ref={gridRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-5">
              {services.map((service, index) => {
                const Icon = service.icon;
                return (
                  <div
                    key={index}
                    className="group bg-cream-50 dark:bg-ink/80 p-6 lg:p-8 rounded-2xl border border-ink/5 dark:border-cream-50/5 transition-all duration-300 hover:-translate-y-1 hover:shadow-card dark:hover:shadow-card-dark"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="p-2.5 bg-forest/10 dark:bg-forest/20 rounded-xl">
                        <Icon size={22} className="text-forest" />
                      </div>
                      <span className={`px-2.5 py-1 text-[10px] font-mono uppercase tracking-wider rounded-full border ${getTagClasses(service.tagColor)}`}>
                        {service.tag}
                      </span>
                    </div>
                    <h3 className="font-serif text-lg text-ink dark:text-cream-50 mb-2">
                      {service.title}
                    </h3>
                    <p className="text-sm text-warmgray leading-relaxed">
                      {service.description}
                    </p>
                  </div>
                );
              })}
            </div>

            {/* Note */}
            <div ref={noteRef} className="mt-12 text-center">
              <p className="text-sm text-warmgray">
                16+ agents total — don't see what you need?{' '}
                <a
                  href="#contact"
                  onClick={(e) => handleNavClick(e, '#contact')}
                  className="text-forest hover:underline"
                >
                  Talk to us about a custom build
                </a>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Dark CTA Band */}
      <section ref={ctaRef} className="dark-band py-20 lg:py-28">
        <div className="section-container">
          <div className="content-container text-center">
            <h2 className="font-serif text-cream-50 mb-6 max-w-3xl mx-auto">
              Ready to stop doing work that AI should be doing?
            </h2>
            <p className="text-cream-50/60 max-w-xl mx-auto mb-8">
              Book a 20-minute discovery call. We'll map your workflow and recommend the first agent to build.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <a
                href="#contact"
                onClick={(e) => handleNavClick(e, '#contact')}
                className="inline-flex items-center justify-center px-6 py-3 bg-forest text-white font-sans font-medium text-sm rounded-full transition-all duration-200 hover:-translate-y-0.5 hover:scale-[1.01]"
              >
                Book a Free Call
              </a>
              <a
                href="#services"
                onClick={(e) => handleNavClick(e, '#services')}
                className="inline-flex items-center justify-center px-6 py-3 bg-transparent text-cream-50 font-sans font-medium text-sm rounded-full border border-cream-50/20 transition-all duration-200 hover:-translate-y-0.5 hover:bg-cream-50/5"
              >
                See Pricing
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
