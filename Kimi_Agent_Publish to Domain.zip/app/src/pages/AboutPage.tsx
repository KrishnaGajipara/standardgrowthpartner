import { useElementReveal } from '../hooks/useScrollReveal';
import { Check, Code2, Zap, Shield } from 'lucide-react';

const values = [
  {
    title: 'Fit the business, don\'t change it',
    description: 'We build around your existing workflows and tools. No forcing square pegs into round holes. Your processes stay intact—we just make them faster.',
    icon: Check,
  },
  {
    title: 'Speed is a feature, not a bonus',
    description: 'First agent live in 72 hours. Not weeks. Not months. We believe the best way to prove value is to ship quickly and iterate based on real usage.',
    icon: Zap,
  },
  {
    title: 'We maintain what we build',
    description: 'This isn\'t a handoff-and-forget service. We stay on call, monitor performance, and continuously improve your agents as your business evolves.',
    icon: Shield,
  },
];

export function AboutPage() {
  const heroRef = useElementReveal<HTMLDivElement>({ y: 30 });
  const valuesRef = useElementReveal<HTMLDivElement>({ y: 40, stagger: 0.12 });
  const teamRef = useElementReveal<HTMLDivElement>({ y: 30 });
  const ctaRef = useElementReveal<HTMLDivElement>({ y: 30 });

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    window.location.hash = href;
  };

  return (
    <div className="relative pt-24 lg:pt-32">
      {/* Split Hero Section */}
      <section className="py-16 lg:py-24 bg-cream-50 dark:bg-ink">
        <div className="section-container">
          <div ref={heroRef} className="content-container">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start">
              {/* Left: Headline */}
              <div>
                <span className="eyebrow block mb-4">About Us</span>
                <h1 className="font-serif text-ink dark:text-cream-50">
                  We built this because the tools already{' '}
                  <span className="accent-italic">existed.</span>{' '}
                  The build didn't.
                </h1>
              </div>

              {/* Right: Body Text */}
              <div className="lg:pt-12">
                <div className="space-y-6 text-warmgray leading-relaxed">
                  <p>
                    Every real estate team and small business we spoke to had the same problem: they knew AI could help, but they didn't have the time or expertise to build it themselves. And the off-the-shelf solutions never quite fit.
                  </p>
                  <p>
                    So we started Standard Growth Partners—not as another SaaS product, but as a done-for-you service. We design, build, and maintain AI agents that integrate directly into the tools you already use. No new logins. No new interfaces. Just work that gets done faster.
                  </p>
                  <p>
                    Our approach is simple: understand your workflow, identify the highest-impact automation, and ship a working agent within 72 hours. Then we stick around to improve it.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Grid */}
      <section className="py-20 lg:py-28 bg-cream-100 dark:bg-ink/40">
        <div className="section-container">
          <div className="content-container">
            <div className="text-center mb-12 lg:mb-16">
              <span className="eyebrow block mb-4">Our Principles</span>
              <h2 className="font-serif text-ink dark:text-cream-50">
                How we work
              </h2>
            </div>

            <div ref={valuesRef} className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
              {values.map((value, index) => {
                const Icon = value.icon;
                return (
                  <div
                    key={index}
                    className="bg-cream-50 dark:bg-ink/80 p-8 lg:p-10 rounded-2xl border border-ink/5 dark:border-cream-50/5"
                  >
                    <div className="p-3 bg-forest/10 dark:bg-forest/20 rounded-xl w-fit mb-6">
                      <Icon size={24} className="text-forest" />
                    </div>
                    <h3 className="font-serif text-xl text-ink dark:text-cream-50 mb-4">
                      {value.title}
                    </h3>
                    <p className="text-sm text-warmgray leading-relaxed">
                      {value.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Team Placeholder */}
      <section className="py-20 lg:py-28 bg-cream-50 dark:bg-ink">
        <div className="section-container">
          <div ref={teamRef} className="content-container">
            <div className="surface-alt p-12 lg:p-20 rounded-2xl text-center">
              <div className="p-4 bg-forest/10 dark:bg-forest/20 rounded-xl w-fit mx-auto mb-6">
                <Code2 size={28} className="text-forest" />
              </div>
              <span className="font-mono text-sm text-forest mb-4 block">
                // team.coming_soon()
              </span>
              <h3 className="font-serif text-2xl text-ink dark:text-cream-50 mb-3">
                Team profiles coming soon
              </h3>
              <p className="text-warmgray max-w-md mx-auto">
                We're a small team of engineers and operators who've built AI systems for startups, enterprises, and everything in between.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Dark CTA Band */}
      <section ref={ctaRef} className="dark-band py-20 lg:py-28">
        <div className="section-container">
          <div className="content-container text-center">
            <h2 className="font-serif text-cream-50 mb-6 max-w-3xl mx-auto">
              Ready to stop doing work that AI should be doing?
            </h2>
            <p className="text-cream-50/60 max-w-xl mx-auto mb-8">
              Book a 20-minute discovery call. We'll map your workflow and recommend the first agent to build.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <a
                href="#contact"
                onClick={(e) => handleNavClick(e, '#contact')}
                className="inline-flex items-center justify-center px-6 py-3 bg-forest text-white font-sans font-medium text-sm rounded-full transition-all duration-200 hover:-translate-y-0.5 hover:scale-[1.01]"
              >
                Book a Free Call
              </a>
              <a
                href="#services"
                onClick={(e) => handleNavClick(e, '#services')}
                className="inline-flex items-center justify-center px-6 py-3 bg-transparent text-cream-50 font-sans font-medium text-sm rounded-full border border-cream-50/20 transition-all duration-200 hover:-translate-y-0.5 hover:bg-cream-50/5"
              >
                See Pricing
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
