import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';
import { useElementReveal } from '../hooks/useScrollReveal';

gsap.registerPlugin(ScrollTrigger);

const integrations = [
  'Follow Up Boss', 'HubSpot', 'Salesforce', 'Google Calendar', 
  'Zillow', 'Twilio', 'Zapier', 'n8n', 'Stripe', 'QuickBooks', 'Slack'
];

const realEstatePainPoints = [
  'Leads slip through after hours',
  'Scheduling eats your day',
  'Listings need better descriptions—fast',
  'Market updates take too long to compile',
  'CRM hygiene never stays current',
];

const businessPainPoints = [
  'Inbox overflow every morning',
  'Invoicing delays cash flow',
  'Content calendar is always behind',
  'Support tickets pile up',
  'Reporting feels like a second job',
];

const processSteps = [
  {
    number: '01',
    title: 'Discovery Call',
    description: 'We map your workflow and pick the first agent to build.',
  },
  {
    number: '02',
    title: 'Choose Your Agents',
    description: 'Select from proven templates or request a custom build.',
  },
  {
    number: '03',
    title: 'We Build & Integrate',
    description: 'We connect your CRM, calendar, and messaging. You review.',
  },
  {
    number: '04',
    title: 'Live in 72 Hours',
    description: 'Agent goes live. We hand off a simple runbook + support.',
  },
];

export function HomePage() {
  const heroRef = useRef<HTMLDivElement>(null);
  const heroContentRef = useRef<HTMLDivElement>(null);
  const heroImageRef = useRef<HTMLDivElement>(null);
  const triggersRef = useRef<ScrollTrigger[]>([]);

  // Hero entrance animation
  useEffect(() => {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) return;

    const ctx = gsap.context(() => {
      // Image entrance
      gsap.fromTo(
        heroImageRef.current,
        { opacity: 0, x: -40 },
        { opacity: 1, x: 0, duration: 0.9, ease: 'power2.out' }
      );

      // Content entrance
      const contentElements = heroContentRef.current?.querySelectorAll('.hero-animate');
      if (contentElements) {
        gsap.fromTo(
          contentElements,
          { opacity: 0, y: 24 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            stagger: 0.1,
            ease: 'power2.out',
            delay: 0.2,
          }
        );
      }
    }, heroRef);

    return () => ctx.revert();
  }, []);

  // Hero scroll exit animation
  useEffect(() => {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) return;

    const ctx = gsap.context(() => {
      // Content exit on scroll
      const contentTrigger = ScrollTrigger.create({
        trigger: heroRef.current,
        start: 'top top',
        end: 'bottom top',
        scrub: 0.5,
        onUpdate: (self) => {
          if (heroContentRef.current) {
            gsap.set(heroContentRef.current, {
              y: -self.progress * 100,
              opacity: 1 - self.progress * 0.6,
            });
          }
        },
      });
      triggersRef.current.push(contentTrigger);

      // Image parallax
      const imageTrigger = ScrollTrigger.create({
        trigger: heroRef.current,
        start: 'top top',
        end: 'bottom top',
        scrub: 0.5,
        onUpdate: (self) => {
          if (heroImageRef.current) {
            gsap.set(heroImageRef.current, {
              y: self.progress * 60,
              scale: 1 + self.progress * 0.03,
            });
          }
        },
      });
      triggersRef.current.push(imageTrigger);
    }, heroRef);

    return () => {
      triggersRef.current.forEach(st => st.kill());
      triggersRef.current = [];
      ctx.revert();
    };
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    window.location.hash = href;
  };

  const counterRef = useElementReveal<HTMLDivElement>({ y: 40, stagger: 0.12 });
  const cardsRef = useElementReveal<HTMLDivElement>({ y: 50, stagger: 0.15 });
  const processRef = useElementReveal<HTMLDivElement>({ y: 40, stagger: 0.1 });
  const ctaRef = useElementReveal<HTMLDivElement>({ y: 30 });

  return (
    <div className="relative">
      {/* Section 1: Hero */}
      <section
        ref={heroRef}
        className="relative min-h-screen flex items-center overflow-hidden"
      >
        {/* Left Image Panel */}
        <div
          ref={heroImageRef}
          className="absolute left-0 top-0 w-full lg:w-1/2 h-full"
        >
          <div className="relative w-full h-full">
            <img
              src="https://images.unsplash.com/photo-1497215728101-856f4ea42174?w=1200&q=80"
              alt="Modern office workspace"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-transparent to-cream-50/20 dark:to-ink/20 lg:hidden" />
          </div>
        </div>

        {/* Right Content Panel */}
        <div className="relative w-full lg:w-1/2 lg:ml-auto min-h-screen flex items-center">
          <div
            ref={heroContentRef}
            className="w-full px-6 sm:px-8 lg:px-[6vw] py-24 lg:py-0"
          >
            <div className="max-w-xl">
              <span className="hero-animate eyebrow block mb-6">
                Custom AI Agents
              </span>
              
              <h1 className="hero-animate font-serif font-medium text-ink dark:text-cream-50 mb-6">
                We build the AI that works{' '}
                <span className="accent-italic">while you grow.</span>
              </h1>
              
              <p className="hero-animate text-lg text-warmgray leading-relaxed mb-8">
                Done-for-you agents that follow up, schedule, write, and report—integrated into the tools you already use. No new software to learn.
              </p>
              
              <div className="hero-animate flex flex-wrap items-center gap-4">
                <a
                  href="#contact"
                  onClick={(e) => handleNavClick(e, '#contact')}
                  className="btn-primary"
                >
                  Book a Free Call
                </a>
                <a
                  href="#services"
                  onClick={(e) => handleNavClick(e, '#services')}
                  className="inline-flex items-center gap-2 text-sm font-medium text-ink dark:text-cream-50 hover:text-forest dark:hover:text-forest transition-colors"
                >
                  See What We Build
                  <ArrowRight size={16} />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Divider Line */}
        <div className="hidden lg:block absolute left-1/2 top-0 w-px h-full bg-ink/10 dark:bg-cream-50/10" />
      </section>

      {/* Section 2: Counter Strip + Integrations */}
      <section className="py-16 lg:py-20 bg-cream-100 dark:bg-ink/40">
        <div className="section-container">
          <div className="content-container">
            {/* Counters */}
            <div ref={counterRef} className="grid grid-cols-1 sm:grid-cols-3 gap-8 lg:gap-12 mb-12">
              <div className="text-center">
                <span className="font-serif text-5xl lg:text-6xl font-medium text-forest">16+</span>
                <p className="mt-2 text-sm text-warmgray">AI Agents Built</p>
              </div>
              <div className="text-center">
                <span className="font-serif text-5xl lg:text-6xl font-medium text-forest">72hrs</span>
                <p className="mt-2 text-sm text-warmgray">First Agent Live</p>
              </div>
              <div className="text-center">
                <span className="font-serif text-5xl lg:text-6xl font-medium text-forest">$0</span>
                <p className="mt-2 text-sm text-warmgray">New Software Required</p>
              </div>
            </div>

            {/* Integrations Marquee */}
            <div className="border-t border-ink/10 dark:border-cream-50/10 pt-8">
              <span className="eyebrow block text-center mb-6">Integrates With</span>
              <div className="relative overflow-hidden">
                <div className="flex animate-marquee">
                  {[...integrations, ...integrations].map((integration, index) => (
                    <span
                      key={index}
                      className="flex-shrink-0 px-6 py-2 text-sm text-warmgray whitespace-nowrap"
                    >
                      {integration}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 3: Two Audience Cards */}
      <section className="py-20 lg:py-28 bg-cream-50 dark:bg-ink">
        <div className="section-container">
          <div className="content-container">
            <div ref={cardsRef} className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8">
              {/* Real Estate Card */}
              <div className="surface p-8 lg:p-10 min-h-[500px] lg:min-h-[600px] flex flex-col">
                <span className="tag-forest mb-auto">Real Estate</span>
                <div>
                  <h3 className="font-serif text-2xl lg:text-3xl text-ink dark:text-cream-50 mb-6">
                    Real Estate Professionals
                  </h3>
                  <ul className="space-y-4">
                    {realEstatePainPoints.map((point, index) => (
                      <li
                        key={index}
                        className="flex items-start gap-3 text-sm text-warmgray"
                      >
                        <span className="w-1 h-1 rounded-full bg-forest mt-2 flex-shrink-0" />
                        {point}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Business Owners Card */}
              <div className="surface p-8 lg:p-10 min-h-[500px] lg:min-h-[600px] flex flex-col">
                <span className="tag-terracotta mb-auto">Business Owners</span>
                <div>
                  <h3 className="font-serif text-2xl lg:text-3xl text-ink dark:text-cream-50 mb-6">
                    Business Owners
                  </h3>
                  <ul className="space-y-4">
                    {businessPainPoints.map((point, index) => (
                      <li
                        key={index}
                        className="flex items-start gap-3 text-sm text-warmgray"
                      >
                        <span className="w-1 h-1 rounded-full bg-terracotta mt-2 flex-shrink-0" />
                        {point}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 4: 4-Step Process */}
      <section className="py-20 lg:py-28 bg-cream-200 dark:bg-ink/60">
        <div className="section-container">
          <div className="content-container">
            <div className="text-center mb-12 lg:mb-16">
              <span className="eyebrow block mb-4">How It Works</span>
              <h2 className="font-serif text-ink dark:text-cream-50 mb-4">
                How we build your first agent
              </h2>
              <p className="text-warmgray max-w-xl mx-auto">
                A lightweight process. No long workshops. No code for you to write.
              </p>
            </div>

            <div ref={processRef} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {processSteps.map((step, index) => (
                <div
                  key={index}
                  className="bg-cream-50 dark:bg-ink/80 p-6 lg:p-8 rounded-2xl border border-ink/5 dark:border-cream-50/5"
                >
                  <span className="font-mono text-sm text-forest mb-4 block">
                    // {step.number}
                  </span>
                  <h4 className="font-serif text-lg text-ink dark:text-cream-50 mb-3">
                    {step.title}
                  </h4>
                  <p className="text-sm text-warmgray leading-relaxed">
                    {step.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Section 5: Dark CTA Band */}
      <section ref={ctaRef} className="dark-band py-20 lg:py-28">
        <div className="section-container">
          <div className="content-container text-center">
            <h2 className="font-serif text-cream-50 mb-6 max-w-3xl mx-auto">
              Ready to stop doing work that AI should be doing?
            </h2>
            <p className="text-cream-50/60 max-w-xl mx-auto mb-8">
              Book a 20-minute discovery call. We'll map your workflow and recommend the first agent to build.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <a
                href="#contact"
                onClick={(e) => handleNavClick(e, '#contact')}
                className="inline-flex items-center justify-center px-6 py-3 bg-forest text-white font-sans font-medium text-sm rounded-full transition-all duration-200 hover:-translate-y-0.5 hover:scale-[1.01]"
              >
                Book a Free Call
              </a>
              <a
                href="#services"
                onClick={(e) => handleNavClick(e, '#services')}
                className="inline-flex items-center justify-center px-6 py-3 bg-transparent text-cream-50 font-sans font-medium text-sm rounded-full border border-cream-50/20 transition-all duration-200 hover:-translate-y-0.5 hover:bg-cream-50/5"
              >
                See Pricing
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
