import { useElementReveal } from '../hooks/useScrollReveal';
import { Calendar, Zap, Shield } from 'lucide-react';

const contactItems = [
  {
    icon: Calendar,
    title: 'Discovery Call',
    description: '30 min free',
  },
  {
    icon: Zap,
    title: 'Fast turnaround',
    description: '72hrs first agent',
  },
  {
    icon: Shield,
    title: 'Fully custom',
    description: 'Built for your workflow',
  },
];

export function ContactPage() {
  const heroRef = useElementReveal<HTMLDivElement>({ y: 30 });
  const contentRef = useElementReveal<HTMLDivElement>({ y: 40, stagger: 0.1 });

  return (
    <div className="relative pt-24 lg:pt-32">
      {/* Hero Section */}
      <section className="py-16 lg:py-20 bg-cream-50 dark:bg-ink">
        <div className="section-container">
          <div ref={heroRef} className="content-container text-center">
            <span className="eyebrow block mb-4">Get In Touch</span>
            <h1 className="font-serif text-ink dark:text-cream-50 mb-6">
              Let's talk about what we can{' '}
              <span className="accent-italic">build for you.</span>
            </h1>
            <p className="text-lg text-warmgray max-w-2xl mx-auto">
              Tell us what slows you down. We'll recommend the right agent and give you a clear timeline.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section with Calendly */}
      <section className="py-16 lg:py-24 bg-cream-100 dark:bg-ink/40">
        <div className="section-container">
          <div ref={contentRef} className="content-container">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
              {/* Left: Contact Info */}
              <div className="space-y-8">
                <div className="space-y-6 text-warmgray leading-relaxed">
                  <p>
                    Ready to see what AI can do for your business? Book a free 30-minute discovery call. We'll learn about your workflow, identify the best first agent to build, and give you a clear timeline.
                  </p>
                  <p>
                    No pressure, no generic pitch—just a conversation about what you need and how we can help.
                  </p>
                </div>

                {/* Contact Items */}
                <div className="space-y-4 pt-4">
                  {contactItems.map((item, index) => {
                    const Icon = item.icon;
                    return (
                      <div
                        key={index}
                        className="flex items-center gap-4 p-4 bg-cream-50 dark:bg-ink/80 rounded-xl border border-ink/5 dark:border-cream-50/5"
                      >
                        <div className="p-2.5 bg-forest/10 dark:bg-forest/20 rounded-lg">
                          <Icon size={20} className="text-forest" />
                        </div>
                        <div>
                          <h4 className="font-sans font-medium text-sm text-ink dark:text-cream-50">
                            {item.title}
                          </h4>
                          <p className="text-xs text-warmgray">{item.description}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Email */}
                <div className="pt-4">
                  <span className="eyebrow block mb-2">Email</span>
                  <a
                    href="mailto:hello@standardgrowth.partners"
                    className="text-ink dark:text-cream-50 hover:text-forest dark:hover:text-forest transition-colors"
                  >
                    hello@standardgrowth.partners
                  </a>
                </div>
              </div>

              {/* Right: Calendly Embed */}
              <div className="bg-cream-50 dark:bg-ink/80 rounded-2xl border border-ink/5 dark:border-cream-50/5 overflow-hidden">
                <div className="p-4 border-b border-ink/5 dark:border-cream-50/5">
                  <h3 className="font-serif text-lg text-ink dark:text-cream-50">
                    Book a Discovery Call
                  </h3>
                  <p className="text-sm text-warmgray">30 minutes, no obligation</p>
                </div>
                <div className="h-[500px] lg:h-[600px]">
                  <iframe
                    src="https://calendly.com/krishnagajipara215/30min"
                    width="100%"
                    height="100%"
                    frameBorder="0"
                    title="Schedule a discovery call"
                    className="rounded-b-2xl"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Simple Footer CTA */}
      <section className="py-16 lg:py-20 bg-cream-50 dark:bg-ink">
        <div className="section-container">
          <div className="content-container text-center">
            <p className="text-warmgray mb-4">
              Prefer to email? That's fine too.
            </p>
            <a
              href="mailto:hello@standardgrowth.partners"
              className="btn-primary"
            >
              Send us an email
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
