import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import type { Page } from '../App';

interface NavigationProps {
  isScrolled: boolean;
  currentPage: Page;
}

const navLinks: { label: string; href: string; page: Page }[] = [
  { label: 'Home', href: '#home', page: 'home' },
  { label: 'Services', href: '#services', page: 'services' },
  { label: 'About', href: '#about', page: 'about' },
];

export function Navigation({ isScrolled, currentPage }: NavigationProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isVisible, setIsVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  // Hide/show navigation on scroll
  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      // Always show at top
      if (currentScrollY < 100) {
        setIsVisible(true);
      } else {
        // Show when scrolling up, hide when scrolling down
        setIsVisible(currentScrollY < lastScrollY);
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    window.location.hash = href;
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'nav-glass py-3'
            : 'bg-transparent py-5'
        } ${isVisible ? 'translate-y-0' : '-translate-y-full'}`}
      >
        <div className="section-container">
          <div className="flex items-center justify-between">
            {/* Wordmark */}
            <a
              href="#home"
              onClick={(e) => handleNavClick(e, '#home')}
              className="flex flex-col"
            >
              <span className="font-serif text-lg font-medium text-ink dark:text-cream-50 tracking-tight">
                Standard Growth Partners
              </span>
              <span className="font-mono text-[10px] uppercase tracking-[0.15em] text-warmgray">
                ai systems
              </span>
            </a>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-8">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className={`font-sans text-sm font-medium transition-colors ${
                    currentPage === link.page
                      ? 'text-forest'
                      : 'text-ink/70 dark:text-cream-50/70 hover:text-ink dark:hover:text-cream-50'
                  }`}
                >
                  {link.label}
                </a>
              ))}
              <a
                href="#contact"
                onClick={(e) => handleNavClick(e, '#contact')}
                className="btn-primary text-xs"
              >
                Book a Call
              </a>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 text-ink dark:text-cream-50"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div
        className={`fixed inset-0 z-40 md:hidden transition-all duration-300 ${
          isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}
      >
        <div
          className="absolute inset-0 bg-ink/20 dark:bg-ink/60 backdrop-blur-sm"
          onClick={() => setIsMobileMenuOpen(false)}
        />
        <div
          className={`absolute top-0 right-0 w-[280px] h-full bg-cream-50 dark:bg-ink shadow-xl transition-transform duration-300 ${
            isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
        >
          <div className="pt-20 px-6">
            <div className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className={`font-sans text-lg font-medium py-2 border-b border-ink/10 dark:border-cream-50/10 ${
                    currentPage === link.page
                      ? 'text-forest'
                      : 'text-ink dark:text-cream-50'
                  }`}
                >
                  {link.label}
                </a>
              ))}
              <a
                href="#contact"
                onClick={(e) => handleNavClick(e, '#contact')}
                className="btn-primary text-center mt-4"
              >
                Book a Call
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
