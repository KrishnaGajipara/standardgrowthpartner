import { Linkedin } from 'lucide-react';

export function Footer() {
  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    window.location.hash = href;
  };

  return (
    <footer className="bg-ink text-cream-50">
      <div className="section-container py-16 lg:py-20">
        <div className="content-container">
          {/* Main Footer Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8 mb-12">
            {/* Brand Column */}
            <div className="lg:col-span-1">
              <div className="flex flex-col mb-4">
                <span className="font-serif text-xl font-medium tracking-tight">
                  Standard Growth Partners
                </span>
                <span className="font-mono text-[10px] uppercase tracking-[0.15em] text-cream-50/50">
                  ai systems
                </span>
              </div>
              <p className="text-sm text-cream-50/60 leading-relaxed max-w-[280px]">
                Done-for-you AI agents that follow up, schedule, write, and report—integrated into the tools you already use.
              </p>
            </div>

            {/* Company Links */}
            <div>
              <h4 className="font-mono text-xs uppercase tracking-[0.12em] text-cream-50/40 mb-4">
                // Company
              </h4>
              <ul className="space-y-3">
                <li>
                  <a
                    href="#about"
                    onClick={(e) => handleNavClick(e, '#about')}
                    className="text-sm text-cream-50/70 hover:text-cream-50 transition-colors"
                  >
                    About
                  </a>
                </li>
                <li>
                  <a
                    href="#contact"
                    onClick={(e) => handleNavClick(e, '#contact')}
                    className="text-sm text-cream-50/70 hover:text-cream-50 transition-colors"
                  >
                    Contact
                  </a>
                </li>
              </ul>
            </div>

            {/* Product Links */}
            <div>
              <h4 className="font-mono text-xs uppercase tracking-[0.12em] text-cream-50/40 mb-4">
                // Product
              </h4>
              <ul className="space-y-3">
                <li>
                  <a
                    href="#services"
                    onClick={(e) => handleNavClick(e, '#services')}
                    className="text-sm text-cream-50/70 hover:text-cream-50 transition-colors"
                  >
                    Services
                  </a>
                </li>
                <li>
                  <a
                    href="#home"
                    onClick={(e) => handleNavClick(e, '#home')}
                    className="text-sm text-cream-50/70 hover:text-cream-50 transition-colors"
                  >
                    How It Works
                  </a>
                </li>
              </ul>
            </div>

            {/* Get Started Links */}
            <div>
              <h4 className="font-mono text-xs uppercase tracking-[0.12em] text-cream-50/40 mb-4">
                // Get Started
              </h4>
              <ul className="space-y-3">
                <li>
                  <a
                    href="#contact"
                    onClick={(e) => handleNavClick(e, '#contact')}
                    className="text-sm text-cream-50/70 hover:text-cream-50 transition-colors"
                  >
                    Book a Call
                  </a>
                </li>
                <li>
                  <a
                    href="https://calendly.com/krishnagajipara215/30min"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-cream-50/70 hover:text-cream-50 transition-colors"
                  >
                    Schedule 30min
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom Row */}
          <div className="pt-8 border-t border-cream-50/10 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-xs text-cream-50/40">
              &copy; {new Date().getFullYear()} Standard Growth Partners. All rights reserved.
            </p>
            <div className="flex items-center gap-6">
              <a
                href="#"
                className="text-xs text-cream-50/40 hover:text-cream-50/70 transition-colors"
              >
                Privacy
              </a>
              <a
                href="#"
                className="text-xs text-cream-50/40 hover:text-cream-50/70 transition-colors"
              >
                Terms
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-cream-50/40 hover:text-cream-50/70 transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin size={16} />
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
