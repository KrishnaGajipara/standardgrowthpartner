import { useState, useEffect } from 'react';
import { Sun, Moon, Calendar } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface FloatingButtonsProps {
  isDark: boolean;
  toggleTheme: () => void;
}

export function FloatingButtons({ isDark, toggleTheme }: FloatingButtonsProps) {
  const [isCalendlyOpen, setIsCalendlyOpen] = useState(false);
  const [showButtons, setShowButtons] = useState(false);

  useEffect(() => {
    // Show buttons after scrolling a bit
    const handleScroll = () => {
      setShowButtons(window.scrollY > 300);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      {/* Theme Toggle - Bottom Left */}
      <button
        onClick={toggleTheme}
        className={`fixed bottom-6 left-6 z-40 p-3 rounded-full bg-cream-100 dark:bg-ink/80 border border-ink/10 dark:border-cream-50/20 text-ink dark:text-cream-50 shadow-card dark:shadow-card-dark transition-all duration-300 hover:-translate-y-0.5 ${
          showButtons ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
        }`}
        aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
      >
        {isDark ? <Sun size={20} /> : <Moon size={20} />}
      </button>

      {/* Book a Meeting - Bottom Right */}
      <button
        onClick={() => setIsCalendlyOpen(true)}
        className={`fixed bottom-6 right-6 z-40 flex items-center gap-2 px-5 py-3 bg-forest text-white font-sans font-medium text-sm rounded-full shadow-card dark:shadow-card-dark transition-all duration-300 hover:-translate-y-0.5 hover:scale-[1.02] ${
          showButtons ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
        }`}
      >
        <Calendar size={18} />
        <span>Book a Meeting</span>
      </button>

      {/* Calendly Dialog */}
      <Dialog open={isCalendlyOpen} onOpenChange={setIsCalendlyOpen}>
        <DialogContent className="max-w-4xl w-[95vw] h-[85vh] p-0 bg-cream-50 dark:bg-ink border border-ink/10 dark:border-cream-50/20">
          <DialogHeader className="p-4 border-b border-ink/10 dark:border-cream-50/10">
            <DialogTitle className="font-serif text-xl">Book a Discovery Call</DialogTitle>
          </DialogHeader>
          <div className="flex-1 h-[calc(85vh-80px)]">
            <iframe
              src="https://calendly.com/krishnagajipara215/30min"
              width="100%"
              height="100%"
              frameBorder="0"
              title="Schedule a meeting"
              className="rounded-b-lg"
            />
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
